import Paragraph from "./components/paragraph";

function App() {
  return (
    <div>
      <Paragraph />
      <br />
      <Paragraph />
    </div>
  );
}

export default App;


